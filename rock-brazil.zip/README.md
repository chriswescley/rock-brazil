# Rock Brazil WordPress Theme

Tema WordPress customizado para portal de notícias de rock com visual geek/cyberpunk.

## Instalação
1. Faça upload da pasta rock-brazil para wp-content/themes/
2. Ative o tema no WordPress
3. Crie as categorias: noticias, reviews, entrevistas, shows, lancamentos, cultura
4. Configure as redes sociais em Aparência > Personalizar

## Features
- Visual cyberpunk/geek
- Matrix background animado
- Contador de views
- Slider automático
- Sistema de posts relacionados
- Totalmente responsivo